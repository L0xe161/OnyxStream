# OnyxStream (package: `moviejoy`)

A bilingual (English / Arabic, full RTL) streaming browser built on Next.js 16 (App Router), React 19, TypeScript, Tailwind v4, shadcn/ui + Radix, Zustand, Framer Motion and TanStack Query.

## Run

```bash
cp .env.example .env.local      # then fill in TMDB_API_KEY and SUBDL_API_KEY
npm install
npm run typecheck               # see docs/CHANGES.md: run this once, then remove ignoreBuildErrors
npm run dev
```

The app refuses to serve TMDB or subtitle data without those two server-side keys (it returns a 503 and logs which variable is missing). Keys are never sent to the browser.

## Structure

| Path | Purpose |
| --- | --- |
| `src/app/page.tsx` | Data-driven tab views, tab transitions, scroll restoration |
| `src/app/api/tmdb/[...path]` | TMDB proxy: endpoint and parameter allow-list, bounded cache |
| `src/app/api/subtitles` | SubDL → WebVTT proxy: validated input, host allow-list, size caps |
| `src/components/onyx/overlay.tsx` | The one accessible dialog shell (Radix) used by every overlay |
| `src/components/onyx/settings-sheet.tsx` | Settings & personalization |
| `src/hooks/use-playback.ts` | Seasons, server fallback, progress for the player |
| `src/hooks/use-url-sync.ts` + `src/lib/url-state.ts` | Back button, refresh and shareable links |
| `src/lib/motion.ts` | Motion tokens (durations, easings, distances) |
| `src/lib/themes.ts`, `src/lib/color.ts` | Contrast-guaranteed accents per theme |
| `src/lib/store.ts` | Persisted state, versioned migration (`STORE_VERSION`) |

## Persisted data

State lives in `localStorage` under `onyx-store-v3` (key kept so existing users keep their data). `STORE_VERSION` is 4; `sanitizePersisted` upgrades any older shape, de-duplicates Continue Watching and fills new settings with defaults. Users can export/import everything as JSON from Settings → Data & privacy.

## Deep links

`?tab=catalog&type=tv&genres=18,80&rating=7.5` · `?title=tv-1396` · `?play=tv-1396&s=2&e=5&srv=vidlink` · `?person=525` · `?q=matrix`

## Attribution

This product uses the TMDB API but is not endorsed or certified by TMDB. Third-party embed providers are not operated by this project; confirm their terms and your local law before deploying publicly.
